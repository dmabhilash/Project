﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement
{
    public class Student : IComparable<Student>
    {
        private string stuNo;
        private string telephone;
        private string name;
        private int age;
        private string gender;
       
       
        public Student() { }

     
        public Student(string stuNo, string telephone, string name, int age, string gender)
        {
            this.stuNo = stuNo;
            this.telephone = telephone;
            this.name = name;
            this.age = age;
            this.gender = gender;

        }
        public override int GetHashCode()
        {
            int prime = 31;
            int result = 1;
            result = prime * result + ((stuNo == null) ? 0 : stuNo.GetHashCode());
            return result;

        }
        

        public string getStuNo()
        {
            return stuNo;
        }
        public void setStuNo(string stuNo)
        {
            this.stuNo = stuNo;
        }
        public string getTelephone()
        {
            return telephone;
        }
        public void setTelephone(string telephone)
        {
            this.telephone = telephone;
        }
        public string getName()
        {
            return name;
        }
        public void setName(string name)
        {
            this.name = name;
        }
        public int getAge()
        {
            return age;
        }
        public void setAge(int age)
        {
            this.age = age;
        }
        public String getGender()
        {
            return gender;
        }
        public void setGender(string gender)
        {
            this.gender = gender;
        }

        public int CompareTo(Student stu)
        {
           
            return stuNo.CompareTo(stu.stuNo);
        }
        
    public override string ToString()
        {
            return "Student [stuNo=" + stuNo + ", telephone=" + telephone + ", name=" + name + ", age=" + age + ", gender="
                    + gender + "]";
        }

    }
} 
