﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace StudentManagement
{
   public class StudentSys
    {
        SortedSet<Student> s = new SortedSet<Student>();


        public Boolean addStu(Student stu)
        {
            // Student object is empty or student ID is empty
            if (stu == null || stu.getStuNo() == null)
            {
                return false;
            }
            // Add students IEnumerable<string> my_slist = GetMyList();
            Boolean flag = s.Add(stu);
            return flag;
        }

        public void showAllStus()
        {
            IEnumerator<Student> my_slist =s.GetEnumerator();
            
            while (my_slist.MoveNext())
            {

                Student s = my_slist.Current;
                Console.WriteLine(s);
            }
        }
        public Student getStuByStuNo(string stuNo)
        {
            IEnumerator<Student> my_slist = s.GetEnumerator();
            while (my_slist.MoveNext())
            {// Loop through the student collection
                Student stu = my_slist.Current;
                // If the student ID of the traversed student object is equal to the student ID passed in, it means that the student was found
                if (stu.getStuNo().Equals(stuNo))
                {
                    return stu;
                }
            }

            return null;
        }


        public Boolean delStu(Student stu)
        {
            return s.Remove(stu);
        }
        public Boolean updateStu(Student stu, Student newStu)
        {
            // If the student object to be modified is empty or the new information object of the student is empty, the modification fails
            if (stu == null || newStu == null)
            {
                return false;
            }

            // Modify student information
            stu.setName(newStu.getName());
            stu.setAge(newStu.getAge());
            stu.setGender(newStu.getGender());
            stu.setTelephone(newStu.getTelephone());

            return true;
        }
        public void init()
        {
            Student stu  = new Student("001", "1891829892", "Ram", 18, "Male");
            Student stu1 = new Student("002", "1891829892", "Mahesh", 19, "Male");
            Student stu2 = new Student("003", "1891829892", "Devi", 17, "Female");
            Student stu3 = new Student("004", "1891829892", "Avinash", 16, "Male");
            Student stu4 = new Student("005", "1891829892", "Suresh", 20, "Male");
            s.Add(stu);
            s.Add(stu1);
            s.Add(stu2);
            s.Add(stu3);
            s.Add(stu4);
        }

        

    }

}

