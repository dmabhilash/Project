﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement
{
    class Program
    {
        public static void Main(string[] args)
        {
           
            StudentSys stuSys = new StudentSys();
            // Initial default student information
            stuSys.init();
            while (true)
            {
                Console.WriteLine("**********Welcome to the student management system**********");
                Console.WriteLine("\t1. Add students");
                Console.WriteLine("\t2. View student information");
                Console.WriteLine("\t3. Modify student information");
                Console.WriteLine("\t4. Delete student");
                Console.WriteLine("\t5. Exit system");
                Console.Write("Please select the required operation:");
                int choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1: // Add students
                            // Enter student information
                        Console.Write("Please enter the student ID:");
                        string stuNo = Console.ReadLine();
                        Console.WriteLine("Please enter the student name:");
                        string name = Console.ReadLine();
                        Console.WriteLine("Please enter the student's age:");
                        int age = int.Parse(Console.ReadLine());
                        Console.Write("Please enter the gender of the student:");
                        string gender = Console.ReadLine();
                        Console.Write("Please enter the student's contact information:");
                        string telephone = Console.ReadLine();

                        Student s = new Student(stuNo, telephone, name, age, gender);
                        // Add students
                        Boolean flag = stuSys.addStu(s);
                        Console.Write("\n");
                        if (flag)
                        {// Add students successfully
                            Console.WriteLine("Add students successfully!");
                        }
                        else
                        {// Failed to add student
                            Console.WriteLine("Failed to add students!");
                        }
                        break;
                    case 2: // View student information
                        Console.WriteLine("****************************");
                        Console.WriteLine("\t1. View all student information");
                        Console.WriteLine("\t2. View specific student information");
                        Console.WriteLine("Please select operation:");
                        choice = int.Parse(Console.ReadLine());
                        switch (choice)
                        {
                            case 1: // View all student information
                                stuSys.showAllStus();
                                break;
                            case 2: // View specific student information
                                Console.Write("Please enter the student ID of the student to be checked:");
                                stuNo = Console.ReadLine();
                                // Find students based on student number
                                s = stuSys.getStuByStuNo(stuNo);
                                if (s == null)
                                {// not found
                                    Console.WriteLine("Check this life!");
                                }
                                else
                                {
                                    Console.WriteLine(s);
                                }
                                break;
                            default:
                                Console.WriteLine("No such operation!");
                                break;
                        }
                        break;

                    case 3:
                        Console.Write("Please enter the student ID of the student to be modified:");
                        stuNo = Console.ReadLine();
                        // Find students based on student number
                        s = stuSys.getStuByStuNo(stuNo);

                        if (s == null)
                        {// not found
                            Console.WriteLine("There are no students to delete!");
                        }
                        else
                        {
                            Console.Write("Please enter the student's new name:");
                            name = Console.ReadLine();

                            Console.Write("Please enter the new age of the student:");
                            age = int.Parse(Console.ReadLine());
                            Console.Write("Please enter the new gender of the student:");
                            gender = Console.ReadLine();
                            Console.Write("Please enter the student's new contact information:");
                            telephone = Console.ReadLine();

                            // Modify student information
                            Student newStu = new Student(s.getStuNo(), telephone, name, age, gender);
                            flag = stuSys.updateStu(s, newStu);

                            if (flag)
                            {
                                Console.WriteLine("Successful student modification!");
                            }
                            else
                            {
                                Console.WriteLine("Failed to modify student!");
                            }
                        }
                        break;
                    case 4:// delete student
                        Console.Write("Please enter the student ID of the student to be checked:");
                        stuNo = Console.ReadLine();

                        // Find students based on student number
                        s = stuSys.getStuByStuNo(stuNo);
                        if (s == null)
                        {// not found
                            Console.WriteLine("There are no students to delete!");
                        }
                        else
                        {
                            
                            flag = stuSys.delStu(s);
                            if (flag)
                            {// Deleted successfully
                                Console.WriteLine("Successfully deleted students!");
                            }
                            else
                            {
                                Console.WriteLine("Failed to delete student!");
                            }
                        }
                        break;
                    case 5:
                        Console.WriteLine("Successful exit from the system!");
                        // exit the program 
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("The selected operation is illegal!");
                        break;
                }

                Console.Write("\n");
            }
        }
    }
}
